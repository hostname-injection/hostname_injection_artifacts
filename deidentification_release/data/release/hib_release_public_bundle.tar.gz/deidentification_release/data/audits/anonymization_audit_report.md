# Anonymization Audit Report

Status: `pass`

```json
{
  "anonymization_shortcut_audit": {
    "estimated_auroc_from_anonymizer_artifacts": 0.5,
    "feature_definition": "released_length_bucket + coarse_character_mask + source_family + time_bucket + obfuscation_family",
    "label_counts": {
      "resolved_benign": 100,
      "verified_executable_semantics": 50
    },
    "majority_label_baseline": 0.6666666666666666,
    "max_feature_label_purity": 0.6666666666666666,
    "n_rows": 150,
    "release_version": "hib-v1.0",
    "status": "pass",
    "tpr_at_1e_minus_4_fpr": 0.0
  },
  "llm_label_reason_handling": {
    "labels_preserved": true,
    "n_label_mismatches": 0,
    "public_llm_reasons_released": false,
    "reason_policy": "Raw LLM reasons are omitted from the public release because they can contain private hostnames, tenants, services, and callback domains. Public labels are preserved exactly via resolved label mapping."
  },
  "n_public_rows": 150,
  "privacy_safety_checks": {
    "emails_usernames_user_ids_device_ids_blockers": 0,
    "exact_raw_canonical_hostname_strings": 0,
    "exact_raw_hostname_strings": 0,
    "forbidden_public_fields": [],
    "intent_signaling_generated_hostnames": 0,
    "ip_addresses_outside_documentation_ranges": 0,
    "live_callback_domains": 0,
    "manual_privacy_review_blockers": 0,
    "n_forbidden_public_fields": 0,
    "raw_internal_suffixes_private_tlds": 0,
    "raw_tenant_customer_name_blockers": 0,
    "secrets_api_keys_jwts_tokens_signed_urls": 0,
    "unsafe_executable_payloads_after_inerting": 0
  },
  "release_version": "hib-v1.0",
  "scanner_coverage": {
    "custom_domain_ip_email_guid_token_scanners": {
      "email_findings": 0,
      "guid_uuid_findings": 0,
      "internal_suffix_findings": 0,
      "non_documentation_ip_findings": 0,
      "secret_token_findings": 0,
      "status": "pass"
    },
    "detect_secrets_or_equivalent": {
      "available": false,
      "n_findings": 0,
      "status": "pass",
      "tool": "custom_regex_entropy_equivalent"
    },
    "exact_match_private_raw_string_scanner": {
      "status": "covered_by_verify_release"
    },
    "manual_stratified_review": {
      "minimum_reviewers": 2,
      "minimum_rows": 10000,
      "public_blockers_recorded": 0,
      "status": "pending_for_full_private_release"
    },
    "public_dns_ct_lookup_policy": {
      "domain_like_outputs": 150,
      "network_lookup_required": false,
      "policy": "Generated domain-like outputs must use reserved suffixes; reserved suffixes are treated as non-resolving and CT-ineligible for release audit purposes.",
      "reserved_namespace_outputs": 150,
      "status": "pass"
    },
    "regex_entropy_secret_scanner": {
      "n_findings": 0,
      "status": "pass"
    },
    "trufflehog_or_equivalent": {
      "available": false,
      "n_findings": 0,
      "status": "pass",
      "tool": "custom_high_risk_token_equivalent"
    }
  },
  "status": "pass",
  "utility_reproducibility_checks": {
    "ccd_flag_agreement_at_paper_threshold": 1.0,
    "ccd_score_spearman_private_vs_public_sample": null,
    "delimiter_position_preservation_rate": 1.0,
    "dns_label_count_preservation_rate": 1.0,
    "encoding_style_preservation_rate": 1.0,
    "evidence_tier_preservation_rate": 1.0,
    "fixed_fpr_metric_reproduction_delta": null,
    "label_preservation_rate": 1.0,
    "normalizer_path_preservation_rate": 1.0,
    "sensitive_span_character_mask_preservation_rate": 1.0,
    "sensitive_span_length_preservation_or_nearest_safe_rate": 1.0,
    "sink_family_preservation_rate": 1.0,
    "unchanged_safe_span_preservation_rate": 1.0
  }
}
```
